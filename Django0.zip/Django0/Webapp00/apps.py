from django.apps import AppConfig


class Webapp00Config(AppConfig):
    name = 'Webapp00'
