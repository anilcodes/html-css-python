from django.shortcuts import render
from .models import SignUp
from django.http import HttpResponseRedirect

# Create your views here.
def show_responsive_bloger(request):
    return render(request,"login & register form.html")

def getData(request):
     fnam = request.POST.get("fname")
     remail= request.POST.get("email")
     rpass= request.POST.get("pass")
     SignUp(fname=fnam,hemail=remail,hpass=rpass).save()
     return HttpResponseRedirect('/')

def validation_view(request):
    ename = request.POST.get("email")
    epass = request.POST.get("pass")
    qs = SignUp.objects.filter(hemail=ename,hpass=epass)
    if not qs:
         return render(request,"login & register form.html",{"msg":"enter valid Email or password"})
    else :
        return render(request,"responsive bloger.html")
#def update_view(request):
  #  return render(request,"login & register form.html")
