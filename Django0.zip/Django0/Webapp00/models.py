from django.db import models

# Create your models here.
class SignUp(models.Model):
    fname = models.CharField(max_length=15)
    hemail = models.CharField(max_length=30,primary_key=True)
    hpass = models.CharField(max_length=8)

